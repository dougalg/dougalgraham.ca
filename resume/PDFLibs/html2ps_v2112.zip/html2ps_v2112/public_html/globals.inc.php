<?php

$GLOBALS['__html_box_id_map'] = array();

?>