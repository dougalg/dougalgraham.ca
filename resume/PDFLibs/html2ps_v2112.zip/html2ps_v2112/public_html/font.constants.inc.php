<?php
// $Header: /cvsroot/html2ps/font.constants.inc.php,v 1.3 2006/07/31 18:19:41 Konstantin Exp $

define('WEIGHT_NORMAL',1);
define('WEIGHT_BOLD',2);

define('FS_NORMAL',1);
define('FS_ITALIC',2);
define('FS_OBLIQUE',3);

?>